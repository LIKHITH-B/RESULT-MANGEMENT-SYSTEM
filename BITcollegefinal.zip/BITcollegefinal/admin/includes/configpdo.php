<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "bit";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>
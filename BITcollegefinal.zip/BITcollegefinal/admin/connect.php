<?php
$conn=mysqli_connect("localhost","root","","bit");
// if($conn){
// 	 echo "connected";
// }
// else{
// 	 echo "not connected";
// }

?>